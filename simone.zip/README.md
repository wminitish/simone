# Commands for fresh setup
1. npm init
2. npm i grunt-cli
3. npm i node-sass
4. npm i grunt-contrib-cssmin
5. npm i grunt-contrib-watch
6. npm rebuild node-sass
7. sudo grunt watch